using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
namespace RaceDay.Mvc.Services;
public class MvcAuthFilter(IHttpContextAccessor accessor) : IAsyncActionFilter
{
    public async Task OnActionExecutionAsync(ActionExecutingContext context,ActionExecutionDelegate next)
    {
        var endpoint=context.HttpContext.GetEndpoint();
        if(endpoint?.Metadata.GetMetadata<Microsoft.AspNetCore.Authorization.AllowAnonymousAttribute>() is not null) { await next(); return; }
        var controller=context.RouteData.Values["controller"]?.ToString();
        if(controller is "Home" or "Auth") { await next(); return; }
        if(string.IsNullOrEmpty(accessor.HttpContext?.Session.GetString("ApiSessionCookie")))
        { context.Result=new RedirectToActionResult("Login","Auth",null); return; }
        await next();
    }
}
