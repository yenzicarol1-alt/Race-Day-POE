using System.Net.Http.Json;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
namespace RaceDay.Mvc.Services;
public class RaceDayApiClient : IRaceDayApiClient
{
    private readonly HttpClient _http; private readonly IHttpContextAccessor _accessor; private readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web) { Converters = { new System.Text.Json.Serialization.JsonStringEnumConverter() } };
    public RaceDayApiClient(HttpClient http, IConfiguration config, IHttpContextAccessor accessor)
    {
        _http=http; _accessor=accessor; _http.BaseAddress=new Uri(config["RaceDayApi:BaseUrl"] ?? "https://localhost:7080/");
        if (_http.BaseAddress.Scheme=="https") _http.DefaultRequestVersion=HttpVersion.Version11;
    }
    private void ApplySessionCookie()
    {
        _http.DefaultRequestHeaders.Remove("Cookie");
        var cookie=_accessor.HttpContext?.Session.GetString("ApiSessionCookie");
        if (!string.IsNullOrWhiteSpace(cookie)) _http.DefaultRequestHeaders.TryAddWithoutValidation("Cookie",cookie);
    }
    public async Task<T?> GetAsync<T>(string path)
    {
        ApplySessionCookie(); using var response=await _http.GetAsync(path);
        if (!response.IsSuccessStatusCode) return default;
        return await response.Content.ReadFromJsonAsync<T>(_json);
    }
    public async Task<T?> SendAsync<T>(HttpMethod method,string path,object? body=null)
    {
        ApplySessionCookie(); using var request=new HttpRequestMessage(method,path);
        if(body is not null) request.Content=JsonContent.Create(body, options:_json);
        using var response=await _http.SendAsync(request);
        if(response.Headers.TryGetValues("Set-Cookie",out var cookies) && method==HttpMethod.Post && path=="api/auth/login")
        {
            var cookie=cookies.FirstOrDefault(x=>x.StartsWith(".RaceDay.Session=",StringComparison.OrdinalIgnoreCase)) ?? cookies.FirstOrDefault(x=>x.Contains(".RaceDay.Session=",StringComparison.OrdinalIgnoreCase));
            if(cookie is not null) _accessor.HttpContext?.Session.SetString("ApiSessionCookie",cookie.Split(';')[0]);
        }
        if(!response.IsSuccessStatusCode) return default;
        if(response.Content.Headers.ContentLength==0) return default;
        return await response.Content.ReadFromJsonAsync<T>(_json);
    }
    public async Task<(bool Success,string? Error)> UploadAsync(string path,IFormFile file,string fieldName="file")
    {
        ApplySessionCookie(); using var form=new MultipartFormDataContent(); await using var stream=file.OpenReadStream();
        using var content=new StreamContent(stream); content.Headers.ContentType=new MediaTypeHeaderValue(file.ContentType);
        form.Add(content,fieldName,file.FileName); using var response=await _http.PostAsync(path,form);
        return (response.IsSuccessStatusCode,response.IsSuccessStatusCode?null:await response.Content.ReadAsStringAsync());
    }
}
