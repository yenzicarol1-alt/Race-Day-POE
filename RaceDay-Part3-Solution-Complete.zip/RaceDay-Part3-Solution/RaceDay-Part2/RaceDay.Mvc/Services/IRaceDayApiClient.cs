using System.Net.Http.Headers;
namespace RaceDay.Mvc.Services;
public interface IRaceDayApiClient
{
    Task<T?> GetAsync<T>(string path);
    Task<T?> SendAsync<T>(HttpMethod method, string path, object? body = null);
    Task<(bool Success, string? Error)> UploadAsync(string path, IFormFile file, string fieldName = "file");
}
