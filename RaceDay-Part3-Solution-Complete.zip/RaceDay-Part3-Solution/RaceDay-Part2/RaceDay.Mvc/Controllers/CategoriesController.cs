using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class CategoriesController(IRaceDayApiClient api):BaseController
{
    public async Task<IActionResult> Manage(int eventId)
    {
        if(!IsOrganiser)return Forbid(); ViewBag.EventId=eventId;
        return View(await api.GetAsync<List<EventsController.CategoryVm>>($"api/events/{eventId}/categories")??new());
    }
    [HttpPost] public async Task<IActionResult> Create(int eventId,string name,string? description,int? minAge,int? maxAge,decimal? distance)
    {
        if(!IsOrganiser)return Forbid();
        await api.SendAsync<object>(HttpMethod.Post,$"api/events/{eventId}/categories",new{name,description,minAge,maxAge,distance});
        return RedirectToAction("Manage",new{eventId});
    }
    [HttpPost] public async Task<IActionResult> Delete(int id,int eventId)
    {
        if(!IsOrganiser)return Forbid();
        await api.SendAsync<object>(HttpMethod.Delete,$"api/categories/{id}");
        return RedirectToAction("Manage",new{eventId});
    }
}
