using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class ProfileController(IRaceDayApiClient api):BaseController
{
    public async Task<IActionResult> Index()=>View(await api.GetAsync<ProfileVm>("api/users/me")??new());
    [HttpPost] public async Task<IActionResult> Update(ProfileVm model)
    {
        await api.SendAsync<ProfileVm>(HttpMethod.Put,"api/users/me",new{model.FirstName,model.LastName,model.PhoneNumber});
        return RedirectToAction("Index");
    }
    [HttpPost] public async Task<IActionResult> Upload(IFormFile file)
    {
        if(file.Length>0) await api.UploadAsync("api/users/me/profile-picture",file);
        return RedirectToAction("Index");
    }
    public class ProfileVm { public int UserId{get;set;} public string FirstName{get;set;}=""; public string LastName{get;set;}=""; public string Email{get;set;}=""; public string? PhoneNumber{get;set;} public string Role{get;set;}=""; public string? ProfileImageUrl{get;set;} }
}
