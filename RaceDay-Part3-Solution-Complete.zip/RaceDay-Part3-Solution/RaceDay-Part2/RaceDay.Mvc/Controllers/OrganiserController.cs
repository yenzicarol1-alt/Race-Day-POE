using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class OrganiserController(IRaceDayApiClient api):BaseController
{
    public async Task<IActionResult> Index()
    {
        if(!IsOrganiser)return Forbid();
        var events=(await api.GetAsync<List<EventsController.EventVm>>("api/events")??new()).Where(e=>e.OrganiserId==UserId).ToList();
        return View(events);
    }
    public async Task<IActionResult> Enrolments(int eventId)
    {
        if(!IsOrganiser)return Forbid();
        ViewBag.EventId=eventId; return View(await api.GetAsync<List<EnrolmentVm>>($"api/events/{eventId}/enrolments")??new());
    }
    [HttpPost] public async Task<IActionResult> AddResult(int enrolmentId,TimeSpan? finishTime,int? finishingPosition)
    {
        if(!IsOrganiser)return Forbid();
        await api.SendAsync<object>(HttpMethod.Post,$"api/enrolments/{enrolmentId}/result",new{finishTime,finishingPosition});
        return RedirectToAction("Index");
    }
    public record EnrolmentVm(int EnrolmentId,int ParticipantId,string ParticipantName,int EventId,string EventName,int CategoryId,string CategoryName,DateTime EnrolmentDate,string Status);
}
