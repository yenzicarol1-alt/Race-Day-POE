using Microsoft.AspNetCore.Mvc;
namespace RaceDay.Mvc.Controllers;
public abstract class BaseController : Controller
{
    protected string? Role => HttpContext.Session.GetString("Role");
    protected int? UserId => HttpContext.Session.GetInt32("UserId");
    protected bool IsOrganiser => Role=="Organiser";
    protected bool IsParticipant => Role=="Participant";
}
