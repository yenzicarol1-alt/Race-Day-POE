using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class ParticipantController(IRaceDayApiClient api):BaseController
{
    public async Task<IActionResult> Index()=>!IsParticipant?Forbid():View(await api.GetAsync<List<EventsController.EventVm>>("api/events")??new());
    public async Task<IActionResult> MyEvents()=>!IsParticipant?Forbid():View(await api.GetAsync<List<OrganiserController.EnrolmentVm>>("api/enrolments/my")??new());
    public async Task<IActionResult> MyResults()=>!IsParticipant?Forbid():View(await api.GetAsync<List<ResultVm>>("api/results/my")??new());
    [HttpPost] public async Task<IActionResult> Enrol(int eventId,int categoryId)
    {
        if(!IsParticipant)return Forbid();
        await api.SendAsync<object>(HttpMethod.Post,$"api/events/{eventId}/enrolments",new{categoryId});
        return RedirectToAction("MyEvents");
    }
    [HttpPost] public async Task<IActionResult> Cancel(int enrolmentId)
    {
        if(!IsParticipant)return Forbid();
        await api.SendAsync<object>(HttpMethod.Delete,$"api/enrolments/{enrolmentId}");
        return RedirectToAction("MyEvents");
    }
    public class ResultVm { public int ResultId{get;set;} public string ParticipantName{get;set;}=""; public string EventName{get;set;}=""; public DateTime EventDate{get;set;} public string CategoryName{get;set;}=""; public TimeSpan? FinishTime{get;set;} public int? FinishingPosition{get;set;} public DateTime? PublishedAt{get;set;} }
}
