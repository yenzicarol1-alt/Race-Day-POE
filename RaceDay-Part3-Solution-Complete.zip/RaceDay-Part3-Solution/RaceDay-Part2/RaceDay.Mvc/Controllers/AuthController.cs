using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class AuthController(IRaceDayApiClient api) : Controller
{
    [HttpGet] public IActionResult Login()=>View();
    [HttpPost] public async Task<IActionResult> Login(string email,string password)
    {
        var user=await api.SendAsync<UserDto>(HttpMethod.Post,"api/auth/login",new { email,password });
        if(user is null) { ViewBag.Error="The email or password is incorrect, or the API could not be reached."; return View(); }
        HttpContext.Session.SetInt32("UserId",user.UserId); HttpContext.Session.SetString("Role",user.Role); HttpContext.Session.SetString("FullName",user.FirstName+" "+user.LastName);
        return RedirectToAction("Index",user.Role=="Organiser"?"Organiser":"Participant");
    }
    [HttpGet] public IActionResult Register()=>View();
    [HttpPost] public async Task<IActionResult> Register(string firstName,string lastName,string email,string password,string? phoneNumber,string role)
    {
        var user=await api.SendAsync<UserDto>(HttpMethod.Post,"api/auth/register",new { firstName,lastName,email,password,phoneNumber,role });
        if(user is null){ ViewBag.Error="Registration failed. Check the details or whether the email is already registered."; return View(); }
        return RedirectToAction("Login");
    }
    public async Task<IActionResult> Logout()
    {
        await api.SendAsync<object>(HttpMethod.Post,"api/auth/logout");
        HttpContext.Session.Clear(); return RedirectToAction("Index","Home");
    }
    public record UserDto(int UserId,string FirstName,string LastName,string Email,string? PhoneNumber,string Role,string? ProfileImageUrl);
}
