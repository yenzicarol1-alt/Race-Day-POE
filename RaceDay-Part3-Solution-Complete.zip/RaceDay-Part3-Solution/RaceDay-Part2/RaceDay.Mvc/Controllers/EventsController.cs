using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class EventsController(IRaceDayApiClient api) : BaseController
{
    [Microsoft.AspNetCore.Authorization.AllowAnonymous]
    public async Task<IActionResult> Index(string? search,string? type)=>View(await api.GetAsync<List<EventVm>>("api/events"+BuildQuery(search,type)));
    [Microsoft.AspNetCore.Authorization.AllowAnonymous]
    public async Task<IActionResult> Details(int id)
    {
        ViewBag.Categories=await api.GetAsync<List<CategoryVm>>($"api/events/{id}/categories");
        return View(await api.GetAsync<EventVm>($"api/events/{id}"));
    }
    [HttpGet] public IActionResult Create()=>IsOrganiser?View(new EventVm()):Forbid();
    [HttpPost] public async Task<IActionResult> Create(EventVm model)
    {
        if(!IsOrganiser)return Forbid();
        var created=await api.SendAsync<EventVm>(HttpMethod.Post,"api/events",model);
        if(created is null){ViewBag.Error="Could not create event. Ensure you are logged in as an organiser.";return View(model);}
        return RedirectToAction("Details",new{id=created.EventId});
    }
    [HttpGet] public async Task<IActionResult> Edit(int id)=>IsOrganiser?View(await api.GetAsync<EventVm>($"api/events/{id}")??new EventVm()):Forbid();
    [HttpPost] public async Task<IActionResult> Edit(int id,EventVm model)
    {
        if(!IsOrganiser)return Forbid();
        var updated=await api.SendAsync<EventVm>(HttpMethod.Put,$"api/events/{id}",model);
        if(updated is null){ViewBag.Error="Unable to update event.";return View(model);}
        return RedirectToAction("Details",new{id});
    }
    [HttpPost] public async Task<IActionResult> Delete(int id){if(!IsOrganiser)return Forbid();await api.SendAsync<object>(HttpMethod.Delete,$"api/events/{id}");return RedirectToAction("Index");}
    [HttpPost] public async Task<IActionResult> UploadBanner(int id,IFormFile file)
    {
        if(!IsOrganiser)return Forbid();
        if(file is not null && file.Length>0){var r=await api.UploadAsync($"api/events/{id}/banner",file);TempData["Message"]=r.Success?"Banner uploaded.":"Banner upload failed.";}
        return RedirectToAction("Details",new{id});
    }
    private static string BuildQuery(string? s,string? t)=>"?"+string.Join("&",new[]{string.IsNullOrWhiteSpace(s)?null:"search="+Uri.EscapeDataString(s),string.IsNullOrWhiteSpace(t)?null:"type="+Uri.EscapeDataString(t)}.Where(x=>x!=null));
    public class EventVm { public int EventId{get;set;} public int OrganiserId{get;set;} public string Name{get;set;}=""; public string? Description{get;set;} public DateTime EventDate{get;set;}=DateTime.Today.AddMonths(1); public string Location{get;set;}=""; public decimal Distance{get;set;} public string EventType{get;set;}="Run"; public string? BannerImageUrl{get;set;} public int EnrolmentCount{get;set;} }
    public class CategoryVm { public int CategoryId{get;set;} public int EventId{get;set;} public string Name{get;set;}=""; public string? Description{get;set;} public int? MinAge{get;set;} public int? MaxAge{get;set;} public decimal? Distance{get;set;} }
}
