using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
namespace RaceDay.Api.Services;
public sealed class AzureBlobStorageService(IConfiguration configuration) : IFileStorageService
{
    public async Task<(string BlobName,string Url)> UploadAsync(Stream stream,string fileName,string contentType,CancellationToken cancellationToken=default)
    {
        var connection=configuration["AzureBlobStorage:ConnectionString"];
        if(string.IsNullOrWhiteSpace(connection) || connection.StartsWith("REPLACE_",StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Configure AzureBlobStorage:ConnectionString before uploading images.");
        var containerName=configuration["AzureBlobStorage:ContainerName"]??"raceday-assets";
        var container=new BlobServiceClient(connection).GetBlobContainerClient(containerName);
       await container.CreateIfNotExistsAsync(
    PublicAccessType.None,
    cancellationToken: cancellationToken);
        var extension=Path.GetExtension(Path.GetFileName(fileName));
        var blobName=$"{Guid.NewGuid():N}{extension}";
        var blob=container.GetBlobClient(blobName);
        await blob.UploadAsync(stream,new BlobHttpHeaders{ContentType=contentType},cancellationToken:cancellationToken);
        return (blobName,blob.Uri.ToString());
    }
    public async Task DeleteAsync(string blobName,CancellationToken cancellationToken=default)
    {
        var connection=configuration["AzureBlobStorage:ConnectionString"];
        if(string.IsNullOrWhiteSpace(connection) || connection.StartsWith("REPLACE_",StringComparison.OrdinalIgnoreCase)) return;
        var container=new BlobServiceClient(connection).GetBlobContainerClient(configuration["AzureBlobStorage:ContainerName"]??"raceday-assets");
        await container.GetBlobClient(blobName).DeleteIfExistsAsync(cancellationToken:cancellationToken);
    }
}
