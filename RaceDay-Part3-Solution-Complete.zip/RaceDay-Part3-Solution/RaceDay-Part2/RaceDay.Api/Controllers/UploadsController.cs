using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Entities;
using RaceDay.Api.Services;
namespace RaceDay.Api.Controllers;
[ApiController,Route("api")]
public class UploadsController(RaceDayDbContext db,IFileStorageService storage):ControllerBase
{
    private int UserId=>int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private static readonly string[] Allowed={"image/jpeg","image/png","image/webp"};
    private async Task<(string Name,string Url)> SaveImage(IFormFile file)
    {
        if(file.Length==0 || file.Length>5*1024*1024) throw new ArgumentException("Image must be between 1 byte and 5 MB.");
        if(!Allowed.Contains(file.ContentType)) throw new ArgumentException("Only JPEG, PNG and WebP images are allowed.");
        await using var stream=file.OpenReadStream();
        return await storage.UploadAsync(stream,file.FileName,file.ContentType,HttpContext.RequestAborted);
    }
    [Authorize,HttpPost("users/me/profile-picture")]
    [RequestSizeLimit(5*1024*1024)]
    public async Task<IActionResult> UploadProfilePicture(IFormFile file)
    {
        if(file is null)return BadRequest(new{message="An image file is required."});
        try { var saved=await SaveImage(file); var user=await db.Users.FindAsync(UserId); if(user is null)return NotFound();
            user.ProfileImageUrl=saved.Url; user.UpdatedAt=DateTime.UtcNow; await db.SaveChangesAsync();
            return Ok(new{profileImageUrl=saved.Url}); }
        catch(ArgumentException ex){return BadRequest(new{message=ex.Message});}
        catch(InvalidOperationException ex){return StatusCode(503,new{message=ex.Message});}
    }
    [Authorize(Roles="Organiser"),HttpPost("events/{eventId:int}/banner")]
    [RequestSizeLimit(5*1024*1024)]
    public async Task<IActionResult> UploadBanner(int eventId,IFormFile file)
    {
        if(file is null)return BadRequest(new{message="An image file is required."});
        var ev=await db.Events.Include(x=>x.Images).SingleOrDefaultAsync(x=>x.EventId==eventId && x.OrganiserId==UserId);
        if(ev is null)return NotFound(new{message="Event not found or you do not own it."});
        try { var saved=await SaveImage(file); ev.BannerImageUrl=saved.Url; ev.UpdatedAt=DateTime.UtcNow;
            db.EventImages.Add(new EventImage{EventId=eventId,BlobName=saved.Name,ImageUrl=saved.Url,IsBanner=true,CreatedAt=DateTime.UtcNow});
            await db.SaveChangesAsync(); return Ok(new{eventId,imageUrl=saved.Url}); }
        catch(ArgumentException ex){return BadRequest(new{message=ex.Message});}
        catch(InvalidOperationException ex){return StatusCode(503,new{message=ex.Message});}
    }
}
