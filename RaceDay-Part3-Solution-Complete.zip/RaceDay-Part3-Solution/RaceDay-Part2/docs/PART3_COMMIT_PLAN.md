# Suggested Part 3 development commits

Make each commit only after the corresponding work is implemented and tested. Do not create artificial commits or commit all work under one message.

1. Add MVC project to solution and configure MVC services.
2. Add API client abstraction and API base URL configuration.
3. Implement API session-cookie forwarding through MVC session.
4. Build shared RaceDay layout and responsive navigation.
5. Add RaceDay home page and public event browsing.
6. Add login page connected to Part 2 API.
7. Add registration page connected to Part 2 API.
8. Add logout and MVC session cleanup.
9. Add authentication filter for protected MVC pages.
10. Add role-specific navigation and controller checks.
11. Build participant event discovery page.
12. Build event details and category listing.
13. Add participant event enrolment workflow.
14. Add participant My Events and cancellation.
15. Add participant My Results page.
16. Build organiser dashboard and event summaries.
17. Add organiser event create/edit/delete pages.
18. Add category management pages.
19. Add organiser enrolment listing and results entry.
20. Add profile view and profile update.
21. Add profile picture upload through API.
22. Add event banner upload through API.
23. Implement Azure Blob Storage service in API.
24. Save uploaded image URLs and metadata in SQL Server.
25. Add responsive styling, validation and friendly error messages.
26. Add Dockerfile and document container run command.
27. Update GitHub Actions to build MVC and run API tests.
28. Update README, capture successful CI screenshot and prepare video.

The rubric requires at least 20 meaningful commits for Part 3.
