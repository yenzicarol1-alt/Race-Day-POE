# Part 3 API changes

Part 3 extends the Part 2 API in the following ways:

- Adds `Azure.Storage.Blobs` and `AzureBlobStorageService`.
- Adds `POST /api/users/me/profile-picture` for authenticated profile picture upload.
- Adds `POST /api/events/{eventId}/banner` for organiser-only event banner upload.
- Stores the resulting image URL in `Users.ProfileImageUrl` or `Events.BannerImageUrl`.
- Stores event banner blob metadata in the existing `EventImages` table.
- Configures JSON enum serialization as strings so the MVC client can send values such as `Organiser`, `Participant`, `Run`, `Walk`, and `Cycle`.

The API remains responsible for database access, authorization and Azure Blob Storage. The MVC application only calls API endpoints.
