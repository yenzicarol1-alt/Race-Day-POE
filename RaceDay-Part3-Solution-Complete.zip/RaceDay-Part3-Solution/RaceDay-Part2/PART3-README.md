# RaceDay Part 3 — MVC Web Application

This project adds an ASP.NET Core MVC front end to the existing RaceDay API. The MVC app calls the Part 2 API for all data operations. It does not connect to SQL Server directly and does not access Azure Blob Storage directly.

## Solution projects
- `RaceDay.Api`: REST API, EF Core and SQL Server. Also receives image uploads and stores them in Azure Blob Storage.
- `RaceDay.Tests`: Part 2 API unit tests.
- `RaceDay.Mvc`: role-aware MVC web application.

## Prerequisites
- Visual Studio 2022 with ASP.NET and web development workload
- .NET 8 SDK
- SQL Server instance compatible with the API connection string
- Azure Storage account and Blob container access for image upload tests

## Configure SQL Server
Edit `RaceDay.Api/appsettings.json` or use user secrets/environment variables for `ConnectionStrings:RaceDay`.

## Configure Azure Blob Storage
Set `AzureBlobStorage:ConnectionString` to the storage account connection string and `AzureBlobStorage:ContainerName` to a container name (default `raceday-assets`). Do not commit real credentials. For example, from the `RaceDay.Api` directory:

```powershell
dotnet user-secrets init
dotnet user-secrets set "AzureBlobStorage:ConnectionString" "<your-storage-connection-string>"
```

The API creates the container if it does not exist. The upload API accepts JPEG, PNG and WebP images up to 5 MB.

## Run locally
1. Open `RaceDay.sln` in Visual Studio.
2. Configure the SQL Server connection string in `RaceDay.Api`.
3. Configure the Azure Blob connection string if you intend to test image uploads.
4. Set `RaceDay.Api` and `RaceDay.Mvc` as multiple startup projects (right-click Solution → Properties → Startup Project → Multiple startup projects).
5. Start `RaceDay.Api` on `https://localhost:7080` and `RaceDay.Mvc` on its configured HTTPS/HTTP launch URL.
6. Browse the MVC application. The MVC app expects the API at `https://localhost:7080/`; change `RaceDayApi:BaseUrl` in `RaceDay.Mvc/appsettings.json` if your API uses another address.

Sample seeded credentials from the API:
- Organiser: `thabo.organiser@raceday.co.za` / `Organiser123!`
- Participant: `participant1@raceday.co.za` / `Participant123!`

## Docker
Build from the repository root:

```powershell
docker build -f Dockerfile -t raceday-mvc .
```

Run (replace the API URL with an address reachable from the container):

```powershell
docker run --rm -p 8080:8080 -e RaceDayApi__BaseUrl=http://host.docker.internal:5080/ raceday-mvc
```

The API must be running separately. In Docker Desktop on Windows, `host.docker.internal` allows the MVC container to reach an API running on the host. Configure API HTTPS/HTTP consistently; do not point the container at `localhost` for a host process.

## CI
`.github/workflows/part3-ci.yml` restores, builds the solution and runs the API test project. Commit and push the workflow, then add a screenshot of the successful Actions run to this README before submission.

## Important implementation notes
- The API session cookie is copied into the MVC server-side session and forwarded on subsequent API requests.
- MVC authorization redirects unauthenticated users to the login page; controller actions also check the user's role.
- Image uploads flow from MVC to API; the API stores images in Azure Blob Storage and saves the resulting URL in SQL Server.
- This is a development starting point. Run the solution and tests locally, review all API responses, complete any lecturer-specific changes and capture your own CI screenshot and unlisted presentation video before submission.
